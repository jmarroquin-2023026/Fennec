
package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;




public class CompraDAO {
    
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    /*Métodos del CRUD*/
    //Método Listar
    
    public List listar(){
        String sql = "Select * from Compra";
        List<Compra> listaCompra = new ArrayList<>();
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while(rs.next()){
                Compra com = new Compra();
                com.setCodigoCompra(rs.getInt(1));
                com.setFecha(rs.getDate(2));
                com.setDescripcion(rs.getString(3));
                com.setTotalDocumento(rs.getDouble(4));
                com.setEstado(rs.getString(5));
                listaCompra.add(com);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return listaCompra;
    }
    
    //Método Agregar
    
    public int agregar(Compra com){
        String sql = "insert into Compra (fecha, descripcion, totalDocumento, estado) values (?,?,?,?)";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            
            ps.setDate(1, com.getFecha());
            ps.setString(2, com.getDescripcion());
            ps.setDouble(3, com.getTotalDocumento());
            ps.setString(4, com.getEstado());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    //Método Buscar por código
    
    public Compra listarCodigoCompra(int id){
        Compra com = new Compra();
        String sql = "select * from Compra where codigoCompra = "+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while(rs.next()){
                com.setCodigoCompra(rs.getInt(1));
                com.setFecha(rs.getDate(2));
                com.setDescripcion(rs.getString(3));
                com.setTotalDocumento(rs.getDouble(4));
                com.setEstado(rs.getString(5));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return com;
    }
    
    //Método Editar
    public int actualizar(Compra com){
        String sql = "Update Compra set fecha = ?, descripcion = ?, totalDocumento = ?, estado = ? where codigoCompra = ?";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            
            ps.setDate(1, com.getFecha());
            ps.setString(2, com.getDescripcion());
            ps.setDouble(3, com.getTotalDocumento());
            ps.setString(4, com.getEstado());
            ps.setInt(5, com.getCodigoCompra());
            ps.executeUpdate();
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    //Método Eliminar
    public void eliminar(int id){
        String sql = "Delete from Compra where codigoCompra = "+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
            
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    
}
