package modelo;

import config.Conexion;
import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class FacturaDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    
   
   //MÉTODO LISTAR
   public List listar(){
       String sql = "Select * from Factura";
       List <Factura> listaFactura = new ArrayList<>();
       try{
           con = cn.Conexion();
           ps = con.prepareStatement(sql);
           rs = ps.executeQuery();
           while(rs.next()){
               Factura fac = new Factura();
               fac.setFacturaID(rs.getInt(1));
               fac.setFechaEmision(rs.getString(2));
               fac.setTotal(rs.getDouble(3));
               fac.setEstado(rs.getString(4));
               fac.setObservaciones(rs.getString(5));
               fac.setClienteID(rs.getInt(6));
               fac.setCodigoEmpleado(rs.getInt(7));
               fac.setCarroId(rs.getInt(8));
               listaFactura.add(fac);
           }
       }catch(Exception e){
           e.printStackTrace();
       }
       return listaFactura;
   }

    
    //MÉTODO AGREGAR
   public int agregar (Factura fact){
       String sql = "Insert into Factura (facturaID, fechaEmision, total, estado, observaciones, clienteID, codigoEmpleado, carroId) values (?, ?, ?, ?, ?, ?, ?, ?)";
       try{
        con = cn.Conexion();
        ps = con.prepareStatement(sql);
        ps.setInt(1, fact.getFacturaID());
        ps.setString(2, fact.getFechaEmision());
        ps.setDouble(3, fact.getTotal());
        ps.setString(4, fact.getEstado());
        ps.setString(5, fact.getObservaciones());
        ps.setInt(6, fact.getClienteID());
        ps.setInt(7, fact.getCodigoEmpleado());
        ps.setInt(8, fact.getCarroId());
        ps.executeUpdate();
       }catch(Exception e){
           e.printStackTrace();
       }
       return resp;
   }
    
    
    //MÉTODO BUSCAR
    public Factura listarFacturaID (int id){
        Factura fact = new Factura();
        String sql = "select * from Factura where facturaID="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                fact.setFacturaID(rs.getInt(1));
                fact.setFechaEmision(rs.getString(2));
                fact.setTotal(rs.getDouble(3));
                fact.setEstado(rs.getString(4));
                fact.setObservaciones(rs.getString(5));
                fact.setClienteID(rs.getInt(6));
                fact.setCodigoEmpleado(rs.getInt(7));
                fact.setCarroId(rs.getInt(8));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return fact;
    }
    
    //MÉTODO EDITAR
    public int actualizar(Factura fact){
        String sql = "Update Factura set  fechaEmision=?, total=?, estado=?, observaciones=?, clienteId=?, codigoEmpleado=?, carroId=? Where facturaID=?";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, fact.getFechaEmision());
            ps.setDouble(2, fact.getTotal());
            ps.setString(3, fact.getEstado());
            ps.setString(4, fact.getObservaciones());
            ps.setInt(5, fact.getClienteID());
            ps.setInt(6, fact.getCodigoEmpleado());
            ps.setInt(7, fact.getCarroId());
            ps.setInt(8, fact.getFacturaID());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    //MÉTODO ELIMINAR
    public void eliminar (int id){
        String sql = "Delete from Factura where facturaID ="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
