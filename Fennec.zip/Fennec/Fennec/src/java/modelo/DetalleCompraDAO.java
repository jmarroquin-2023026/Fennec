
package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class DetalleCompraDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    
    //metodo de listar
     public List listar() {
        String sql = "select * from DetalleCompra";
        List<DetalleCompra> listaDetalleCompra = new ArrayList<>();
        try {
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                DetalleCompra dc = new DetalleCompra();
                dc.setCodigoDetalleCompra(rs.getInt(1));
                dc.setCostoUnitario(rs.getDouble(2));
                dc.setCantidad(rs.getInt(3));
                dc.setObservaciones(rs.getString(4));
                dc.setTipoDePago(rs.getString(5));
                dc.setCarroId(rs.getInt(6));
                dc.setCodigoCompra(rs.getInt(7));
                dc.setCodigoProveedor(rs.getInt(8));
                listaDetalleCompra.add(dc);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaDetalleCompra;
    }
    
    
    //metodo de agregar
    public int agregar(DetalleCompra dc){
        String sql = "insert into DetalleCompra (costoUnitario,cantidad,observaciones,tipoDePago,carroId,codigoCompra,codigoProveedor) values (?,?,?,?,?,?,?)";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setDouble(1, dc.getCostoUnitario());
            ps.setInt(2, dc.getCantidad());
            ps.setString(3, dc.getObservaciones());
            ps.setString(4, dc.getTipoDePago());
            ps.setInt(5, dc.getCarroId());
            ps.setInt(6, dc.getCodigoCompra());
            ps.setInt(7, dc.getCodigoProveedor());
            ps.executeUpdate();
            
            actualizarTotalDocumento(dc.getCodigoCompra());
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    private void actualizarTotalDocumento(int codigoCompra) {
        String sqlUpdate = "UPDATE Compra SET totalDocumento = (SELECT (SUM(costoUnitario * cantidad)) FROM DetalleCompra WHERE codigoCompra = ?) WHERE codigoCompra = ?";
        try {
            ps = con.prepareStatement(sqlUpdate);
            ps.setInt(1, codigoCompra);
            ps.setInt(2, codigoCompra);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    //buscar por codigo
    public DetalleCompra ListarCodigoDetalleCompra(int id ){
        //instanciar un objeto de tipo DetalleCompra
        DetalleCompra dc = new DetalleCompra();
        String sql = "Select * from DetalleCompra where codigoDetalleCompra = "+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                dc.setCodigoDetalleCompra(rs.getInt(1));
                dc.setCostoUnitario(rs.getDouble(2));
                dc.setCantidad(rs.getInt(3));
                dc.setObservaciones(rs.getString(4));
                dc.setTipoDePago(rs.getString(5));
                dc.setCarroId(rs.getInt(6));
                dc.setCodigoCompra(rs.getInt(7));
                dc.setCodigoProveedor(rs.getInt(8));
                
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return dc;
    }
    
    //metodo de editar
    public int actulizar (DetalleCompra dc){
        String sql = "Update DetalleCompra set costoUnitario = ?, cantidad = ?, observaciones = ?,tipoDePago = ? where codigoDetalleCompra =?";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setDouble(1, dc.getCostoUnitario());
            ps.setInt(2, dc.getCantidad());
            ps.setString(3, dc.getObservaciones());
            ps.setString(4, dc.getTipoDePago());
            ps.setInt(5, dc.getCodigoDetalleCompra());
            ps.executeUpdate();
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    //metodo de eliminar
    public void eliminar(int id){
        String sql ="Delete from DetalleCompra where codigoDetalleCompra="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }
    
    
}
