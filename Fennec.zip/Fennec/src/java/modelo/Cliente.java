package modelo;

public class Cliente {
    private int clienteID;
    private String nombresCliente;
    private String apellidosCliente;
    private String direccionCliente;
    private String telefonCliente;
    private String correoCliente;

    public Cliente() {
    }

    public Cliente(int clienteID, String nombresCliente, String apellidosCliente, String direccionCliente, String telefonCliente, String correoCliente) {
        this.clienteID = clienteID;
        this.nombresCliente = nombresCliente;
        this.apellidosCliente = apellidosCliente;
        this.direccionCliente = direccionCliente;
        this.telefonCliente = telefonCliente;
        this.correoCliente = correoCliente;
    }

    public int getClienteID() {
        return clienteID;
    }

    public void setClienteID(int clienteID) {
        this.clienteID = clienteID;
    }

    public String getNombresCliente() {
        return nombresCliente;
    }

    public void setNombresCliente(String nombresCliente) {
        this.nombresCliente = nombresCliente;
    }

    public String getApellidosCliente() {
        return apellidosCliente;
    }

    public void setApellidosCliente(String apellidosCliente) {
        this.apellidosCliente = apellidosCliente;
    }

    public String getDireccionCliente() {
        return direccionCliente;
    }

    public void setDireccionCliente(String direccionCliente) {
        this.direccionCliente = direccionCliente;
    }

    public String getTelefonCliente() {
        return telefonCliente;
    }

    public void setTelefonCliente(String telefonCliente) {
        this.telefonCliente = telefonCliente;
    }

    public String getCorreoCliente() {
        return correoCliente;
    }

    public void setCorreoCliente(String correoCliente) {
        this.correoCliente = correoCliente;
    }
}
