package modelo;

import java.util.Date;

public class Empleados {
    private String DPI;
    private String nombres;
    private String apellidos;
    private Date fechaNacimiento;
    private String correo;
    private String telefono;
    private String usuario;
    private int codigoTipoEmpleado;

    public Empleados() {
    }
    
    public Empleados(String DPI, String nombres, String apellidos, Date fechaNacimiento, String correo, String telefono, String usuario, int codigoTipoEmpleado) {
        this.DPI = DPI;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.fechaNacimiento = fechaNacimiento;
        this.correo = correo;
        this.telefono = telefono;
        this.usuario = usuario;
        this.codigoTipoEmpleado = codigoTipoEmpleado;
    }

    public String getDPI() {
        return DPI;
    }

    public void setDPI(String DPI) {
        this.DPI = DPI;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public int getCodigoTipoEmpleado() {
        return codigoTipoEmpleado;
    }

    public void setCodigoTipoEmpleado(int codigoTipoEmpleado) {
        this.codigoTipoEmpleado = codigoTipoEmpleado;
    }

    @Override
    public String toString() {
        return "Empleados{" + "DPI=" + DPI + ", nombres=" + nombres + ", apellidos=" + apellidos + ", fechaNacimiento=" + fechaNacimiento + ", correo=" + correo + ", telefono=" + telefono + ", usuario=" + usuario + ", codigoTipoEmpleado=" + codigoTipoEmpleado + '}';
    }
    
    
    
}