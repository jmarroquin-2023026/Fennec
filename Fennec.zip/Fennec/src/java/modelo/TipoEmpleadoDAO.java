package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class TipoEmpleadoDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    public List listar(){
        String sql = "Select * From TipoEmpleado";
        List<TipoEmpleado> listaTipoEmpleado = new ArrayList<>();
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery(); 
            while(rs.next()){
                TipoEmpleado temp = new TipoEmpleado();
                temp.setCodigoTipoEmpleado(rs.getInt(1));
                temp.setDescripcion(rs.getString(2));
                temp.setSalarioBase(rs.getDouble(3));
                temp.setBonificacion(rs.getDouble(4));
                temp.setTurno(rs.getString(5));
                listaTipoEmpleado.add(temp);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return listaTipoEmpleado;
    }
    
    public int agregar(TipoEmpleado temp){
        String sql = "insert into TipoEmpleado (descripcion, salarioBase, bonificacion, turno) values (?,?,?,?)";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, temp.getDescripcion());
            ps.setDouble(2, temp.getSalarioBase());
            ps.setDouble(3, temp.getBonificacion());
            ps.setString(4, temp.getTurno());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    public TipoEmpleado listarCodigoTipoEmpleado(int id){
        TipoEmpleado temp = new TipoEmpleado();
        String sql = "Select * From TipoEmpleado where codigoTipoEmpleado = "+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                temp.setCodigoTipoEmpleado(rs.getInt(1));
                temp.setDescripcion(rs.getString(2));
                temp.setSalarioBase(rs.getDouble(3));
                temp.setBonificacion(rs.getDouble(4));
                temp.setTurno(rs.getString(5));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return temp;
    }
    
    public int actualizar(TipoEmpleado temp) {
    String sql = "Update TipoEmpleado set descripcion = ?, salarioBase = ?, bonificacion = ?, turno = ? where codigoTipoEmpleado = ?";
    try {
        con = cn.Conexion();
        ps = con.prepareStatement(sql);
        ps.setString(1, temp.getDescripcion());
        ps.setDouble(2, temp.getSalarioBase());
        ps.setDouble(3, temp.getBonificacion());
        ps.setString(4, temp.getTurno());
        ps.setInt(5, temp.getCodigoTipoEmpleado());
        ps.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return resp;
}


    public void eliminar(int id){
        String sql = "Delete from tipoEmpleado where codigoTipoEmpleado="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        
    }    
}

