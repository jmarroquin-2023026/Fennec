package modelo;
import java.sql.Date;


public class Factura {
    private int facturaID;
    private Date fechaEmision ;
    private double total;
    private String estado;
    private String observaciones;
    private int clienteID;
    private int codigoEmpleado;
    private int carroId;

    public Factura() {
    }

    public Factura(int facturaID, Date fechaEmision, double total, String estado, String observaciones, int clienteID, int codigoEmpleado, int carroId) {
        this.facturaID = facturaID;
        this.fechaEmision = fechaEmision;
        this.total = total;
        this.estado = estado;
        this.observaciones = observaciones;
        this.clienteID = clienteID;
        this.codigoEmpleado = codigoEmpleado;
        this.carroId = carroId;
    }

    public int getFacturaID() {
        return facturaID;
    }

    public void setFacturaID(int facturaID) {
        this.facturaID = facturaID;
    }

    public Date getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(Date fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    public int getClienteID() {
        return clienteID;
    }

    public void setClienteID(int clienteID) {
        this.clienteID = clienteID;
    }

    public int getCodigoEmpleado() {
        return codigoEmpleado;
    }

    public void setCodigoEmpleado(int codigoEmpleado) {
        this.codigoEmpleado = codigoEmpleado;
    }

    public int getCarroId() {
        return carroId;
    }

    public void setCarroId(int carroId) {
        this.carroId = carroId;
    }

    @Override
    public String toString() {
        return "Factura{" + "facturaID=" + facturaID + ", fechaEmision=" + fechaEmision + ", total=" + total + ", estado=" + estado + ", observaciones=" + observaciones + ", clienteID=" + clienteID + ", codigoEmpleado=" + codigoEmpleado + ", carroId=" + carroId + '}';
    }
}