package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ProveedoresDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    public List listar() throws SQLException{
        String sql = "select * from Proveedor";
        List <Proveedores> listaProveedor = new ArrayList <>();
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while(rs.next()){
                Proveedores prov = new Proveedores();
                prov.setCodigoProveedor(rs.getInt(1));
                prov.setNombresProveedor(rs.getString(2));
                prov.setApellidosProveedor(rs.getString(3));
                prov.setDireccionProveedor(rs.getString(4));
                prov.setTelefonoProveedor(rs.getString(5));
                prov.setCorreoProveedor(rs.getString(6));
                prov.setObservacionesProveedor(rs.getString(7));
                
                listaProveedor.add(prov);
            }
            
            
        }catch(Exception e){
            e.printStackTrace();
        }
         return listaProveedor;
    }
    
    public int agregar(Proveedores prov){
        String sql = "insert into Proveedor(nombresProveedor, apellidosProveedor, direccionProveedor, telefonoProveedor, correoProveedor, observacionesProveedor)values(?,?,?,?,?,?)";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, prov.getNombresProveedor());
            ps.setString(2, prov.getApellidosProveedor());
            ps.setString(3, prov.getDireccionProveedor());
            ps.setString(4, prov.getTelefonoProveedor());
            ps.setString(5, prov.getCorreoProveedor());
            ps.setString(6, prov.getObservacionesProveedor());
            
            ps.executeUpdate();
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    
    }
    
    
    public Proveedores listarCodigoProveedor (int id){
        Proveedores prov = new Proveedores();
        String sql = "Select * from Proveedor where codigoProveedor="+id;
        
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while(rs.next()){
                prov.setNombresProveedor(rs.getString (2));
                prov.setApellidosProveedor(rs.getString(3));
                prov.setDireccionProveedor(rs.getString(4));
                prov.setTelefonoProveedor(rs.getString(5));
                prov.setCorreoProveedor(rs.getString(6));
                prov.setObservacionesProveedor(rs.getString(7));
            }
            
        }catch(Exception e){
            e.printStackTrace();
            }
        return prov;
    }
    
    public int actualizar(Proveedores prov){
        String sql = "Update Proveedor set nombresProveedor = ?, apellidosProveedor = ?, direccionProveedor = ?, telefonoProveedor = ?, correoProveedor = ?, observacionesProveedor = ? where codigoProveedor = ?";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, prov.getNombresProveedor());
            ps.setString(2, prov.getApellidosProveedor());
            ps.setString(3, prov.getDireccionProveedor());
            ps.setString(4, prov.getTelefonoProveedor());
            ps.setString(5, prov.getCorreoProveedor());
            ps.setString(6, prov.getObservacionesProveedor());
            ps.setInt(7, prov.getCodigoProveedor());
            
            ps.executeUpdate();
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    
    }
    
    public void eliminar (int id){
        String sql = "Delete from Proveedor where codigoProveedor ="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeQuery();
            
        }catch(Exception e){
            e.printStackTrace();
            
        }
    }
    
}
