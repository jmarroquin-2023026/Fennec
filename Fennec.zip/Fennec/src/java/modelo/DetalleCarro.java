/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Josue
 */
public class DetalleCarro {
    private int codigoDetalleCarro ;
    private String tipoCarro;
    private int puertas;
    private String transmision;
    private String tipoLlantas;
    private String color;
    private int carroId;

    public DetalleCarro() {
    }

    public DetalleCarro(int codigoDetalleCarro, String tipoCarro, int puertas, String transmision, String tipoLlantas, String color, int carroId) {
        this.codigoDetalleCarro = codigoDetalleCarro;
        this.tipoCarro = tipoCarro;
        this.puertas = puertas;
        this.transmision = transmision;
        this.tipoLlantas = tipoLlantas;
        this.color = color;
        this.carroId = carroId;
    }

    public int getCodigoDetalleCarro() {
        return codigoDetalleCarro;
    }

    public void setCodigoDetalleCarro(int codigoDetalleCarro) {
        this.codigoDetalleCarro = codigoDetalleCarro;
    }

    public String getTipoCarro() {
        return tipoCarro;
    }

    public void setTipoCarro(String tipoCarro) {
        this.tipoCarro = tipoCarro;
    }

    public int getPuertas() {
        return puertas;
    }

    public void setPuertas(int puertas) {
        this.puertas = puertas;
    }

    public String getTransmision() {
        return transmision;
    }

    public void setTransmision(String transmision) {
        this.transmision = transmision;
    }

    public String getTipoLlantas() {
        return tipoLlantas;
    }

    public void setTipoLlantas(String tipoLlantas) {
        this.tipoLlantas = tipoLlantas;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getCarroId() {
        return carroId;
    }

    public void setCarroId(int carroId) {
        this.carroId = carroId;
    }

    @Override
    public String toString() {
        return "DetalleCarro{" + "codigoDetalleCarro=" + codigoDetalleCarro + ", tipoCarro=" + tipoCarro + ", puertas=" + puertas + ", transmision=" + transmision + ", tipoLlantas=" + tipoLlantas + ", color=" + color + ", carroId=" + carroId + '}';
    }
    
    
}
