
package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CarroDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    
    
    // Los métodos del CRUD
    //Método Listar
    
    public List listar(){
        String sql = "Select * From Carro";
        List <Carro> listaCarro = new ArrayList <>();
        
        try{
            con = cn.Conexion();
            ps= con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while(rs.next()){
                Carro ca = new Carro();
                ca.setCarroId(rs.getInt(1));
                ca.setVIN(rs.getInt(2));
                ca.setMarca(rs.getString(3));
                ca.setModelo(rs.getString(4));
                ca.setAnio(rs.getInt(5));
                ca.setPrecio(rs.getDouble(6));
                
                listaCarro.add(ca);
                
            }
        }catch (Exception error){
            error.printStackTrace();
        }
        
        return listaCarro;
    }
    
    //Método Agregar
    
    public int agregar(Carro car){
        String sql = "insert into Carro (VIN, marca, modelo, anio, precio) values(?,?,?,?,?)";
        try{    
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            
            ps.setInt(1, car.getVIN());
            ps.setString(2, car.getMarca());
            ps.setString(3, car.getModelo());
            ps.setInt(4,car.getAnio());
            ps.setDouble(5, car.getPrecio());
            
            ps.executeUpdate();
                    
        }catch (Exception error){
            error.printStackTrace();
        }
        return resp;
    }
    
    
    //Método por Código
    public Carro listarCodigoCarro (int id){
        Carro car = new Carro();
        String sql = "Select * from Carro where carroId ="+ id;
        
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            
            while (rs.next()){
                car.setCarroId(rs.getInt(1));
                car.setVIN(rs.getInt(2));
                car.setMarca(rs.getString(3));
                car.setModelo(rs.getString(4));
                car.setAnio(rs.getInt(5));
                car.setPrecio(rs.getDouble(6));
            }
            
        }catch(Exception error){
            error.printStackTrace();
        }
        return car;
    }
    
    //Método de Editar
    
    public int actualizar(Carro car){
        String sql = "Update Carro set VIN = ?, marca = ?, modelo = ?, anio = ?, precio = ? where carroId = ?";
        
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            
            ps.setInt(1, car.getVIN());
            ps.setString(2, car.getMarca());
            ps.setString(3, car.getModelo());
            ps.setInt(4,car.getAnio());
            ps.setDouble(5, car.getPrecio());
            ps.setInt(6, car.getCarroId());
            
            ps.executeUpdate();
            
        }catch (Exception error){
            error.printStackTrace();
        }
        return resp;
    }
    
    //Método Eliminar
    
    public void eliminar (int id){
        String sql = "Delete from Carro where carroId =" + id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception error){
            error.printStackTrace();
        }
        
    }
 
}
