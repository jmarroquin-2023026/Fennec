package modelo;

import config.Conexion;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletResponse;

public class EmpleadoDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    
    public Empleado validar(String usuario, String DPI){
        Empleado empleado = new Empleado();
        String sql = "Select * from Empleado where usuario= ? and DPI = ?";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, DPI);
            rs = ps.executeQuery();
            while(rs.next()){
                empleado.setCodigoEmpleado(rs.getInt("codigoEmpleado"));
                empleado.setDPI(rs.getString("DPI"));
                empleado.setNombres(rs.getString("nombres"));
                empleado.setCorreo(rs.getString("correo"));
                empleado.setUsuario(rs.getString("usuario"));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return empleado;
    }
    
    //CRUD
    //LISTAR
    public List listar(){
        String sql = "Select * from Empleado";
        List <Empleado> listaEmpleado = new ArrayList<>();
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Empleado em = new Empleado();
                em.setCodigoEmpleado(rs.getInt(1));
                em.setDPI(rs.getString(2));
                em.setNombres(rs.getString(3));
                em.setApellidos(rs.getString(4));
                em.setFechaNacimiento(rs.getString(5));
                em.setCorreo(rs.getString(6));
                em.setTelefono(rs.getString(7));
                em.setUsuario(rs.getString(8));
                em.setImagen(rs.getBinaryStream(9));
                em.setCodigoTipoEmpleado(rs.getInt(10));
                listaEmpleado.add(em);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return listaEmpleado;
    }
    
    
    public void listarImg (int id, HttpServletResponse response){
        String sql="Select * from Empleado where codigoEmpleado="+id;
        InputStream inputStream = null;
        OutputStream outputStream = null;
        BufferedInputStream bufferInput = null;
        BufferedOutputStream bufferOut = null;
        response.setContentType("image/*");
        try{
            outputStream = response.getOutputStream();
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if(rs.next()){
                inputStream = rs.getBinaryStream("imagen");
            }
            bufferInput = new BufferedInputStream(inputStream);
            bufferOut = new BufferedOutputStream(outputStream);
            int i=0;
            while((i = bufferInput.read())!=-1){
                bufferOut.write(i);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    //AGREGAR
    public int agregar(Empleado emp){
        String sql = "INSERT INTO Empleado (DPI, Nombres, Apellidos, Correo, Telefono, usuario, imagen, codigoTipoEmpleado) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, emp.getDPI());
            ps.setString(2, emp.getNombres());
            ps.setString(3, emp.getApellidos());
            ps.setString(4, emp.getFechaNacimiento());
            ps.setString(5, emp.getCorreo());
            ps.setString(6, emp.getTelefono());
            ps.setString(7, emp.getUsuario());
            ps.setBlob(8, emp.getImagen());
            ps.setInt(9, emp.getCodigoTipoEmpleado());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
     return resp;   
    }
    
    //Buscar por DPI
    public Empleado listarCodigoEmpleado (int id){
        Empleado emp = new Empleado();
        String sql = "select * from Empleado where codigoEmpleado ="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()){
                emp.setCodigoEmpleado(rs.getInt(1));
                emp.setDPI(rs.getString(2));
                emp.setNombres(rs.getString(3));
                emp.setApellidos(rs.getString(4));
                emp.setFechaNacimiento(rs.getString(5));
                emp.setCorreo(rs.getString(6));
                emp.setTelefono(rs.getString(7));
                emp.setUsuario(rs.getString(8));
                emp.setImagen(rs.getBinaryStream(9));
                emp.setCodigoTipoEmpleado(rs.getInt(10));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return emp;
    }
    
    //Editar
    public int actualizar(Empleado emp){
        String sql = "Update Empleado set DPI = ?, nombres = ?, apellidos = ?, fechaNacimiento = ?, correo = ?, telefono = ?, usuario = ?, imagen = ? where codigoEmpleado = ?";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, emp.getDPI());
            ps.setString(2, emp.getNombres());
            ps.setString(3, emp.getApellidos());
            ps.setString(4, emp.getFechaNacimiento());
            ps.setString(5, emp.getCorreo());
            ps.setString(6, emp.getTelefono());
            ps.setString(7, emp.getUsuario());
            ps.setBlob(8, emp.getImagen());
            ps.setInt(9, emp.getCodigoEmpleado());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    //Eliminar
    public void eliminar (int id){
        String sql = "Delete from Empleado where codigoEmpleado ="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
