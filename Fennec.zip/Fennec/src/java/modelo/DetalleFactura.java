/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Josue
 */
public class DetalleFactura {
    private int detalleFacturaID;
    private double precioUnitario;
    private double subTotal;
    private double descuento;
    private int item;
    private int codCarro;
    private String nomCliente;
    private String descrip;
    private double precio;
    private int facId;
    private int canti;
    

    public DetalleFactura() {
    }

    public DetalleFactura(int detalleFacturaID, double precioUnitario, double subTotal, double descuento, int item, int codCarro, String nomCliente, String descrip, double precio, int facId, int canti) {
        this.detalleFacturaID = detalleFacturaID;
        this.precioUnitario = precioUnitario;
        this.subTotal = subTotal;
        this.descuento = descuento;
        this.item = item;
        this.codCarro = codCarro;
        this.nomCliente = nomCliente;
        this.descrip = descrip;
        this.precio = precio;
        this.facId = facId;
        this.canti = canti;
    }

    public int getDetalleFacturaID() {
        return detalleFacturaID;
    }

    public void setDetalleFacturaID(int detalleFacturaID) {
        this.detalleFacturaID = detalleFacturaID;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public double getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(double subTotal) {
        this.subTotal = subTotal;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public int getItem() {
        return item;
    }

    public void setItem(int item) {
        this.item = item;
    }

    public int getCodCarro() {
        return codCarro;
    }

    public void setCodCarro(int codCarro) {
        this.codCarro = codCarro;
    }

    public String getNomCliente() {
        return nomCliente;
    }

    public void setNomCliente(String nomCliente) {
        this.nomCliente = nomCliente;
    }

    public String getDescrip() {
        return descrip;
    }

    public void setDescrip(String descrip) {
        this.descrip = descrip;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getFacId() {
        return facId;
    }

    public void setFacId(int facId) {
        this.facId = facId;
    }

    public int getCanti() {
        return canti;
    }

    public void setCanti(int canti) {
        this.canti = canti;
    }
    
    
    
    

   
}