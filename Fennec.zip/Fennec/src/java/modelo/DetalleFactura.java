/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Josue
 */
public class DetalleFactura {
    private int detalleFacturaID;
    private int cantidad;
    private double precioUnitario;
    private double subTotal;
    private double descuento;
    private int facturaID;

    public DetalleFactura() {
    }

    public DetalleFactura(int detalleFacturaID, int cantidad, double precioUnitario, double subTotal, double descuento, int facturaID) {
        this.detalleFacturaID = detalleFacturaID;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
        this.subTotal = subTotal;
        this.descuento = descuento;
        this.facturaID = facturaID;
    }

    public int getDetalleFacturaID() {
        return detalleFacturaID;
    }

    public void setDetalleFacturaID(int detalleFacturaID) {
        this.detalleFacturaID = detalleFacturaID;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }

    public double getSubTotal() {
        return subTotal;
    }

    public void setSubTotal(double subTotal) {
        this.subTotal = subTotal;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }

    public int getFacturaID() {
        return facturaID;
    }

    public void setFacturaID(int facturaID) {
        this.facturaID = facturaID;
    }

    @Override
    public String toString() {
        return "DetalleFactura{" + "detalleFacturaID=" + detalleFacturaID + ", cantidad=" + cantidad + ", precioUnitario=" + precioUnitario + ", subTotal=" + subTotal + ", descuento=" + descuento + ", facturaID=" + facturaID + '}';
    }
    
    
}
