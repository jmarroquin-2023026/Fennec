package modelo;

public class TipoEmpleado {
    private int codigoTipoEmpleado;
    private String descripcion;
    private double salarioBase;
    private double bonificacion;
    private String turno;
    
    public TipoEmpleado() {
    }

    public TipoEmpleado(int codigoTipoEmpleado, String descripcion, double salarioBase, double bonificacion, String turno) {
        this.codigoTipoEmpleado = codigoTipoEmpleado;
        this.descripcion = descripcion;
        this.salarioBase = salarioBase;
        this.bonificacion = bonificacion;
        this.turno = turno;
    }

    public int getCodigoTipoEmpleado() {
        return codigoTipoEmpleado;
    }

    public void setCodigoTipoEmpleado(int codigoTipoEmpleado) {
        this.codigoTipoEmpleado = codigoTipoEmpleado;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }

    public double getBonificacion() {
        return bonificacion;
    }

    public void setBonificacion(double bonificacion) {
        this.bonificacion = bonificacion;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    @Override
    public String toString() {
        return "TipoEmpleado{" + "codigoTipoEmpleado=" + codigoTipoEmpleado + ", descripcion=" + descripcion + ", salarioBase=" + salarioBase + ", bonificacion=" + bonificacion + ", turno=" + turno + '}';
    }    
}
