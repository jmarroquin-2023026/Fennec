package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmpleadosDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    public Empleados validar(String usuario, String DPI){
        Empleados empleado = new Empleados();
        String sql = "Select * from Empleado where usuario= ? and DPI = ?";
        try{
            //se estable la conexion
            con = cn.Conexion();
            
            //la consulta
            ps = con.prepareStatement(sql);
            
            //le asiganmos quienes son los parametros
            ps.setString(1, usuario);
            ps.setString(2, DPI);
            
            //en el rs(resultSet se guarda la consulta con todos los datos)
            rs = ps.executeQuery();
            
            while(rs.next()){
                empleado.setDPI(rs.getString("DPI"));
                empleado.setNombres(rs.getString("nombres"));
                empleado.setApellidos(rs.getString("apellidos"));
                empleado.setFechaNacimiento(rs.getDate("fechaNacimiento")); 
                empleado.setCorreo(rs.getString("correo"));
                empleado.setTelefono(rs.getString("telefono"));
                empleado.setUsuario(rs.getString("usuario"));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return empleado;
    }
    
    //CRUD
    //LISTAR
    public List listar(){
        String sql = "Select * from Empleado";
        List <Empleados> listaEmpleado = new ArrayList<>();
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Empleados em = new Empleados();
                em.setDPI(rs.getString(1));
                em.setNombres(rs.getString(2));
                em.setApellidos(rs.getString(3));
                em.setFechaNacimiento(rs.getDate(4));
                em.setCorreo(rs.getString(5));
                em.setTelefono(rs.getString(6));
                em.setUsuario(rs.getString(7));
                em.setCodigoTipoEmpleado(rs.getInt(8));
                listaEmpleado.add(em);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return listaEmpleado;
    }
    
    //AGREGAR
    public int agregar(Empleados emp){
        String sql = "INSERT INTO Empleado (DPI, Nombres, Apellidos, FechaNacimiento, Correo, Telefono, Usuario, codigoTipoEmpleado) VALUES ('?', '?', '?', '?', '?', '?', ?, ?)";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, emp.getDPI());
            ps.setString(2, emp.getNombres());
            ps.setString(3, emp.getApellidos());
            ps.setDate(4, (Date) emp.getFechaNacimiento());
            ps.setString(5, emp.getCorreo());
            ps.setString(6, emp.getTelefono());
            ps.setString(7, emp.getUsuario());
            ps.setInt(8, emp.getCodigoTipoEmpleado());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
     return resp;   
    }
    
    //Buscar por DPI
    public Empleados listarDPI (int id){
        Empleados emp = new Empleados();
        String sql = "select * from Empleado where DPI ="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()){
                emp.setDPI(rs.getString(1));
                emp.setNombres(rs.getString(2));
                emp.setApellidos(rs.getString(3));
                emp.setFechaNacimiento(rs.getDate(4));
                emp.setCorreo(rs.getString(5));
                emp.setTelefono(rs.getString(6));
                emp.setUsuario(rs.getString(7));
                emp.setCodigoTipoEmpleado(rs.getInt(8));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        
        return emp;
    }
    
    //Editar
    public int actualizar(Empleados emp){
        String sql = "Update Empleado set DPI = ?, nombre = ?, apellidos = ? , fechaNacimiento = ?, correo = ?, telefono = ?, usuario = ?, codigoTipoEmpleado = ?";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setString(1, emp.getDPI());
            ps.setString(2, emp.getNombres());
            ps.setString(3, emp.getApellidos());
            ps.setDate(4, (Date) emp.getFechaNacimiento());
            ps.setString(5, emp.getCorreo());
            ps.setString(6, emp.getTelefono());
            ps.setString(7, emp.getUsuario());
            ps.setInt(8, emp.getCodigoTipoEmpleado());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    //Eliminar
    public void eliminar (int id){
        String sql = "Delete from Empleado where DPI = "+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
