package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class EmpleadosDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    
    public Empleados validar(int DPI, String usuario){
        Empleados empleado = new Empleados();
        String sql = "Select * from Empleado where usuario= ? and DPI = ?";
        try{
            //se estable la conexion
            con = cn.Conexion();
            
            //la consulta
            ps = con.prepareStatement(sql);
            
            //le asiganmos quienes son los parametros
            ps.setInt(1, DPI);
            ps.setString(2, usuario);
            
            //en el rs(resultSet se guarda la consulta con todos los datos)
            rs = ps.executeQuery();
            
            while(rs.next()){
                empleado.setDPI(rs.getInt("DPI"));
                empleado.setNombres(rs.getString("nombres"));
                empleado.setApellidos(rs.getString("apellidos"));
                empleado.setCorreo(rs.getString("correo"));
                empleado.setTelefono(rs.getString("telefono"));
                empleado.setUsuario(rs.getString("usuario"));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return empleado;
    }
}
