
package modelo;

public class Carro {
    private int carroId;
    private int VIN;
    private String marca;
    private String modelo;
    private int anio;
    private double precio;

    public Carro() {
    }

    public Carro(int carroId, int VIN, String marca, String modelo, int anio, double precio) {
        this.carroId = carroId;
        this.VIN = VIN;
        this.marca = marca;
        this.modelo = modelo;
        this.anio = anio;
        this.precio = precio;
    }

    public int getCarroId() {
        return carroId;
    }

    public void setCarroId(int carroId) {
        this.carroId = carroId;
    }

    public int getVIN() {
        return VIN;
    }

    public void setVIN(int VIN) {
        this.VIN = VIN;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Carro{" + "carroId=" + carroId + ", VIN=" + VIN + ", marca=" + marca + ", modelo=" + modelo + ", anio=" + anio + ", precio=" + precio + '}';
    }
    
    
    
    
    
    
}
