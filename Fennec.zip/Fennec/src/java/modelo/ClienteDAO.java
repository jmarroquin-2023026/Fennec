package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
   Conexion cn = new Conexion();
   Connection con;
   PreparedStatement ps;
   ResultSet rs;
   int resp;
   
   public List listar(){
        String sql = "Select * From Cliente";
        List <Cliente> listaCliente = new ArrayList <>();
        
        try{
            con = cn.Conexion();
            ps= con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Cliente cl = new Cliente();
                cl.setClienteID(rs.getInt(1));
                cl.setNombre(rs.getString(2));
                cl.setApellido(rs.getString(3));
                cl.setDireccion(rs.getString(4));
                cl.setTelefono(rs.getString(5));
                cl.setCorreo(rs.getString(6));
                listaCliente.add(cl);
                
            }
        }catch (Exception error){
            error.printStackTrace();
        }
        
        return listaCliente;
    }
   
    public int agregar(Cliente cli){
        String sql = "insert into Cliente (nombre, apellido, direccion, telefono, correo) values(?,?,?,?,?)";
        try{    
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            
            ps.setString(1, cli.getNombre());
            ps.setString(2, cli.getApellido());
            ps.setString(3, cli.getDireccion());
            ps.setString(4, cli.getTelefono());
            ps.setString(5, cli.getCorreo());
            
            ps.executeUpdate();
                    
        }catch (Exception error){
            error.printStackTrace();
        }
        return resp;
    }
   
    public Cliente listarCodigoCliente (int id){
        Cliente cli = new Cliente();
        String sql = "Select * from Cliente where clienteID="+ id;
        
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            
            while (rs.next()){
                cli.setClienteID(rs.getInt(1));
                cli.setNombre(rs.getString(2));
                cli.setApellido(rs.getString(3));
                cli.setDireccion(rs.getString(4));
                cli.setTelefono(rs.getString(5));
                cli.setCorreo(rs.getString(6));
            }
            
        }catch(Exception error){
            error.printStackTrace();
        }
        return cli;
    } 
    
    public int actualizar(Cliente cli){
        String sql = "Update Cliente set nombre = ?, apellido = ?, direccion = ?, telefono = ?, correo = ? where clienteID = ?";
        
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            
            ps.setString(1, cli.getNombre());
            ps.setString(2, cli.getApellido());
            ps.setString(3, cli.getDireccion());
            ps.setString(4,cli.getTelefono());
            ps.setString(5, cli.getCorreo());
            ps.setInt(6, cli.getClienteID());
            
            ps.executeUpdate();
            
        }catch (Exception error){
            error.printStackTrace();
        }
        return resp;
    }
    
    public void eliminar (int id){
        String sql = "Delete from Cliente where clienteID =" + id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception error){
            error.printStackTrace();
        }
        
    }
   
   
   
}
