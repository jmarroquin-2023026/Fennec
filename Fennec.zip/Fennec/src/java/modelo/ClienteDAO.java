package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    //CRUD
    //METODO LISTAR
    
    public List listar(){
        String sql = "Select * from Cliente";
        List <Cliente> listaCliente = new ArrayList <>();
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Cliente cliente = new Cliente();
                cliente.setClienteID(rs.getInt(1));
                cliente.setNombresCliente(rs.getString(2));
                cliente.setApellidosCliente(rs.getString(3));
                cliente.setDireccionCliente(rs.getString(4));
                cliente.setTelefonCliente(rs.getString(5));
                cliente.setCorreoCliente(rs.getString(6));
                
                listaCliente.add(cliente);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return listaCliente;
    }
    
    //METODO AGREGAR
    public int agregar(Cliente cliente){
        String sql = "Insert into Cliente(nombre, apellido, aireccion, teléfono, correo) values(?,?,?,?,?)";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            
            ps.setString(1, cliente.getNombresCliente());
            ps.setString(2, cliente.getApellidosCliente());
            ps.setString(3, cliente.getDireccionCliente());
            ps.setString(4, cliente.getTelefonCliente());
            ps.setString(5, cliente.getCorreoCliente());
            
            ps.executeUpdate();
            
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    //METODO POR CODIGO
    public Cliente listarCodigoCliente (int id){
        Cliente cliente = new Cliente();
        String sql = "Select * from Cliente where clienteID="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                cliente.setNombresCliente(rs.getString(2));
                cliente.setApellidosCliente(rs.getString(3));
                cliente.setDireccionCliente(rs.getString(4));
                cliente.setTelefonCliente(rs.getString(5));
                cliente.setCorreoCliente(rs.getString(6));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return cliente;
    }
    
    //METODO EDITAR
    public int actualizar(Cliente cliente){
        String sql = "Update Cliente set nombre = ?, apellido = ?, iareccion = ?, teléefono = ?, correo = ? where clienteID = ?";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            
            ps.setInt(1, cliente.getClienteID());
            ps.setString(2, cliente.getNombresCliente());
            ps.setString(3, cliente.getApellidosCliente());
            ps.setString(4, cliente.getDireccionCliente());
            ps.setString(5, cliente.getTelefonCliente());
            ps.setString(6, cliente.getCorreoCliente());
            
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    //METODO ELIMINAR
    public void eliminar (int id){
        String sql = "Delete from Cliente where clienteID=" +id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
