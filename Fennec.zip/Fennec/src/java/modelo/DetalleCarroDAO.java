/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Josue
 */
public class DetalleCarroDAO {
    Conexion cn= new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    //Metodo listar
    public List listar(){
        String sql ="Select * from DetalleCarro";
        List<DetalleCarro> listaDetalleCarro = new ArrayList<>();
        try{
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                DetalleCarro dc= new DetalleCarro();
                dc.setCodigoDetalleCarro(rs.getInt(1));
                dc.setTipoCarro(rs.getString(2));
                dc.setPuertas(rs.getInt(3));
                dc.setTransmision(rs.getString(4));
                dc.setTipoLlantas(rs.getString(5));
                dc.setColor(rs.getString(6));
                dc.setCarroId(rs.getInt(7));
                listaDetalleCarro.add(dc);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return listaDetalleCarro;
    }
    
    //Metodo agregar
    public int agregar(DetalleCarro dc){
        String sql="insert into DetalleCarro(codigoDetalleCarro, tipoCarro,puertas,transmision,tipoLlantas,color,carroId) values (?,?,?,?,?,?,?)";
        try{
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setInt(1, dc.getCodigoDetalleCarro());
            ps.setString(2, dc.getTipoCarro());
            ps.setInt(3, dc.getPuertas());
            ps.setString(4, dc.getTransmision());
            ps.setString(5, dc.getTipoLlantas());
            ps.setString(6, dc.getColor());
            ps.setInt(7, dc.getCarroId());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    //buscar por codigo
    
    public DetalleCarro listaCodigoDetalleCarro(int id){
        DetalleCarro dc= new DetalleCarro();
         String sql="select * from DetalleCarro where codigoDetalleCarro="+id;
         try{
             con=cn.Conexion();
             ps=con.prepareStatement(sql);
             rs=ps.executeQuery();
             while(rs.next()){
                 dc.setCodigoDetalleCarro(rs.getInt(1));
                 dc.setTipoCarro(rs.getString(2));
                 dc.setPuertas(rs.getInt(3));
                 dc.setTransmision(rs.getString(4));
                 dc.setTipoLlantas(rs.getString(5));
                 dc.setColor(rs.getString(6));
                 dc.setCarroId(rs.getInt(7));
             }
         }catch(Exception e){
             e.printStackTrace();
         }
         return dc;
    }
    
    //metodo editar
    
    public int actulaizar(DetalleCarro dc){
        String sql="Update DetalleCarro set tipoCarro=?, puertas=?, transmision=?, tipoLlantas=?,"
                + "color=? where codigoDetalleCarro=?";
        try{
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setString(1, dc.getTipoCarro());
            ps.setInt(2, dc.getPuertas());
            ps.setString(3, dc.getTransmision());
            ps.setString(4, dc.getTipoLlantas());
            ps.setString(5, dc.getColor());
            ps.setInt(6, dc.getCodigoDetalleCarro());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
     }
    
    //metodo eliminar
    
    public void elminar(int id){
        String sql="Delete from DetalleCarro where codigoDetalleCarro="+id;
        try{
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
