/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Josue
 */
public class DetalleFacturaDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    
    //Metodo Listar
    public List<DetalleFactura> listarDetalleFacturas() {
    String sql = "SELECT * FROM DetalleFactura";
    List<DetalleFactura> detalleFacturaList = new ArrayList<>();
    try (Connection con = cn.Conexion(); 
         PreparedStatement ps = con.prepareStatement(sql); 
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            DetalleFactura df = new DetalleFactura();
            df.setDetalleFacturaID(rs.getInt(1));
            df.setCanti(rs.getInt(2));
            df.setPrecioUnitario(rs.getDouble(3));
            df.setSubTotal(rs.getDouble(4));
            df.setDescuento(rs.getDouble(5));
            df.setFacId(rs.getInt(6));
            detalleFacturaList.add(df);
        }
    } catch (Exception e) {
        e.printStackTrace(); // Consider logging instead
    }
    return detalleFacturaList;
}

    
    //Metodo agregar
    public int agregar(DetalleFactura df) {
    String sql = "insert into DetalleFactura(cantidad, precioUnitario, subTotal, descuento, facturaID) values(?, ?, ?, ?, ?)";
    try {
        con = cn.Conexion();
        ps = con.prepareStatement(sql);
        ps.setInt(1, df.getCanti()); // Cambié el índice de 2 a 1
        ps.setDouble(2, df.getPrecioUnitario()); // Cambié el índice de 3 a 2
        ps.setDouble(3, df.getSubTotal()); // Cambié el índice de 4 a 3
        ps.setDouble(4, df.getDescuento()); // Cambié el índice de 5 a 4
        ps.setInt(5, df.getFacId()); // Cambié el índice de 6 a 5
        resp = ps.executeUpdate();
    } catch (Exception e) {
        e.printStackTrace();
    }
    return resp;
}

    
    //Buscar por codigo
    
    public DetalleFactura ListarCodigoDetalleFactura(int id){
        DetalleFactura df= new DetalleFactura();
        String sql="Select * from DetalleFactura where DetalleFacturaID="+id;
        try{
            con=cn.Conexion();
            ps= con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                df.setDetalleFacturaID(rs.getInt(1));
                df.setCanti(rs.getInt(2));
                df.setPrecioUnitario(rs.getDouble(3));
                df.setSubTotal(rs.getDouble(4));
                df.setDescuento(rs.getDouble(5));
                df.setFacId(rs.getInt(6));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return df;
    }
    
   //Metodo editar
    public int actualizar(DetalleFactura df){
        String sql="Update DetalleFactura set cantidad=?, precioUnitario=?, subTotal=?, descuento=? where DetalleFacturaID=? ";
        try{
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setInt(1, df.getCanti());
            ps.setDouble(2, df.getPrecioUnitario());
            ps.setDouble(3, df.getSubTotal());
            ps.setDouble(4, df.getDescuento());
            ps.setInt(5, df.getDetalleFacturaID());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();       
        }
        return resp;
    }
    
    //Metodo eliminar
    public void eliminar(int id){
        String sql="Delete from DetalleFactura where DetalleFacturaID="+id;
        try{
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    public String GenerarSerie(){
        String numeroserie="";
        String sql = "select max(detalleFacturaID) from DetalleFactura";
        try{
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                numeroserie=rs.getString(sql);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return numeroserie;
    }
}
