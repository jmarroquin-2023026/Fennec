/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Josue
 */
public class DetalleFacturaDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    
    //Metodo Listar
    public List Listar(){
        String sql = "eSelect * from DetalleFactura";
        List<DetalleFactura> listarDetalleFactura= new ArrayList<>();
        try{
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            
            while(rs.next()){
                DetalleFactura df= new DetalleFactura();
                df.setDetalleFacturaID(rs.getInt(1));
                df.setCantidad(rs.getInt(2));
                df.setPrecioUnitario(rs.getDouble(3));
                df.setSubTotal(rs.getDouble(4));
                df.setDescuento(rs.getDouble(5));
                df.setFacturaID(rs.getInt(6));
                listarDetalleFactura.add(df);
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return listarDetalleFactura;
    }
    
    //Metodo agregar
    public int agregar(DetalleFactura df){
        String sql="insert into DetalleFactura(cantidad,precioUnitario,subTotal,descuento,facturaID) values(?,?,?,?,?)";
        try{
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setInt(2, df.getCantidad());
            ps.setDouble(3, df.getPrecioUnitario());
            ps.setDouble(4, df.getSubTotal());
            ps.setDouble(5, df.getDescuento());
            ps.setInt(6, df.getFacturaID());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    //Buscar por codigo
    
    public DetalleFactura ListarCodigoDetalleFactura(int id){
        DetalleFactura df= new DetalleFactura();
        String sql="Select * from DetalleFactura where DetalleFacturaID="+id;
        try{
            con=cn.Conexion();
            ps= con.prepareStatement(sql);
            rs=ps.executeQuery();
            while(rs.next()){
                df.setDetalleFacturaID(rs.getInt(1));
                df.setCantidad(rs.getInt(2));
                df.setPrecioUnitario(rs.getDouble(3));
                df.setSubTotal(rs.getDouble(4));
                df.setDescuento(rs.getDouble(5));
                df.setFacturaID(rs.getInt(6));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return df;
    }
    
   //Metodo editar
    public int actualizar(DetalleFactura df){
        String sql="Update DetalleFactura set cantidad=?, precioUnitario=?, subTotal=?, descuento=? where DetalleFacturaID=? ";
        try{
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.setInt(1, df.getCantidad());
            ps.setDouble(2, df.getPrecioUnitario());
            ps.setDouble(3, df.getSubTotal());
            ps.setDouble(4, df.getDescuento());
            ps.setInt(5, df.getDetalleFacturaID());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();       
        }
        return resp;
    }
    
    //Metodo eliminar
    public void eliminar(int id){
        String sql="Delete from DetalleFactura where DetalleFacturaID="+id;
        try{
            con=cn.Conexion();
            ps=con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
