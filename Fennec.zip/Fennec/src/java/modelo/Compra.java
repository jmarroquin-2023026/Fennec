
package modelo;

public class Compra {
    private int codigoCompra; //tiene auto_increment
    private String fecha;
    private String descripcion;
    private double totalDocumento;
    private String estado;

    public Compra() {
    }

    public Compra(int codigoCompra, String fecha, String descripcion, double totalDocumento, String estado) {
        this.codigoCompra = codigoCompra;
        this.fecha = fecha;
        this.descripcion = descripcion;
        this.totalDocumento = totalDocumento;
        this.estado = estado;
    }

    public int getCodigoCompra() {
        return codigoCompra;
    }

    public void setCodigoCompra(int codigoCompra) {
        this.codigoCompra = codigoCompra;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getTotalDocumento() {
        return totalDocumento;
    }

    public void setTotalDocumento(double totalDocumento) {
        this.totalDocumento = totalDocumento;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Compra{" + "codigoCompra=" + codigoCompra + ", fecha=" + fecha + ", descripcion=" + descripcion + ", totalDocumento=" + totalDocumento + ", estado=" + estado + '}';
    }

    
    
    
}
