/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import modelo.Carro;
import modelo.CarroDAO;
import modelo.Cliente;
import modelo.ClienteDAO;
import modelo.Compra;
import modelo.CompraDAO;
import modelo.DetalleCarro;
import modelo.DetalleCarroDAO;
import modelo.DetalleCompra;
import modelo.DetalleCompraDAO;
import modelo.DetalleFactura;
import modelo.DetalleFacturaDAO;
import modelo.Empleado;
import modelo.EmpleadoDAO;
import modelo.Factura;
import modelo.FacturaDAO;
import modelo.Proveedores;
import modelo.ProveedoresDAO;
import modelo.TipoEmpleado;
import modelo.TipoEmpleadoDAO;

/**
 *
 * @author informatica
 */
@MultipartConfig
public class Controlador extends HttpServlet {
    int codCarroId;
    Empleado empleado = new Empleado();
    EmpleadoDAO empleadoDAO = new EmpleadoDAO();
    int codEmpleado;
    Compra compra = new Compra();
    CompraDAO compraDao = new CompraDAO();
    int codCompra;
    DetalleCompra detalleCompra = new DetalleCompra();
    DetalleCompraDAO detalleCompraDAO = new DetalleCompraDAO();
    int codDetalleCompra;
    DetalleCarro detalleCarro = new DetalleCarro();
    DetalleCarroDAO detalleCarroDao = new DetalleCarroDAO();
    int codiDetalleCarro;
    TipoEmpleado tipoEmpleado = new TipoEmpleado();
    TipoEmpleadoDAO tipoEmpleadoDao = new TipoEmpleadoDAO();
    int codiTipoEmpleado;
    Cliente cliente = new Cliente();
    ClienteDAO clienteDao = new ClienteDAO();
    Carro carro = new Carro();
    CarroDAO carroDao = new CarroDAO();
    DetalleFactura detalleFactura = new DetalleFactura();
    Factura factura = new Factura();
    FacturaDAO facturaDAO = new FacturaDAO();
    int factID;
    List<DetalleFactura> lista = new ArrayList<>();
    int codDetalleFactura;
    int item = 0;
    String nombresCliente;
    int carrID, exist;
    String descripcion;
    double precio, subTotal , totalPagar = 0.0, desc=0.0;
    Proveedores proveedores = new Proveedores();
    ProveedoresDAO proveedoresDao = new ProveedoresDAO();
    int codProveedor;
    int codCliente;
    int factId, carroID, codDf;
    DetalleFacturaDAO detalleFacturaDao = new DetalleFacturaDAO();
    int numeroserie;
    
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        String menu = request.getParameter("menu");// Maneja el cambio e los JSP
        String accion = request.getParameter("accion");//va a manejar siempre los elementos del CRUD
        if(menu.equals("Principal2")){
            request.getRequestDispatcher("Principal2.jsp").forward(request, response);
        }else if(menu.equals("Carro")){
            switch(accion){
                case "Listar":
                    List listaCarro = carroDao.listar();
                    request.setAttribute("Carros", listaCarro);
                    break;
                case "Agregar":
                    int VIN = Integer.parseInt(request.getParameter("txtVIN"));
                    String marca = request.getParameter("txtMarca");
                    String modelo = request.getParameter("txtModelo");
                    int anio = Integer.parseInt(request.getParameter("txtAnio"));
                    double precio = Double.parseDouble(request.getParameter("txtPrecio"));
                    carro.setVIN(VIN);
                    carro.setMarca(marca);
                    carro.setModelo(modelo);
                    carro.setAnio(anio);
                    carro.setPrecio(precio);
                    carroDao.agregar(carro);
                    request.getRequestDispatcher("Controlador?menu=Carro&accion=Listar").forward(request, response);
                    break;
               case "Editar":
                    codCarroId = Integer.parseInt(request.getParameter("carroId"));
                    Carro cr = carroDao.listarCodigoCarro(codCarroId);
                    request.setAttribute("carro", cr);
                    request.getRequestDispatcher("Controlador?menu=Carro&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    int VINCar = Integer.parseInt(request.getParameter("txtVIN"));
                    String marcaCar = request.getParameter("txtMarca");
                    String modeloCar = request.getParameter("txtModelo");
                    int anioCar = Integer.parseInt(request.getParameter("txtAnio"));
                    double precioCar = Double.parseDouble(request.getParameter("txtPrecio"));
                    
                    
                    carro.setVIN(VINCar);
                    carro.setMarca(marcaCar);
                    carro.setModelo(modeloCar);
                    carro.setAnio(anioCar);
                    carro.setPrecio(precioCar);
                    carro.setCarroId(codCarroId);
                    carroDao.actualizar(carro);
                    
                    request.getRequestDispatcher("Controlador?menu=Carro&accion=Listar").forward(request, response);
                    break;
                    
                case "Eliminar":
                    codCarroId = Integer.parseInt(request.getParameter("carroId"));
                    carroDao.eliminar(codCarroId);
                    request.getRequestDispatcher("Controlador?menu=Carro&accion=Listar").forward(request, response);
                    break;    
            }
            request.getRequestDispatcher("Carro.jsp").forward(request, response);
        }else if(menu.equals("Principal")){
            request.getRequestDispatcher("Principal.jsp").forward(request, response);
        }else if(menu.equals("DetalleCompra")){
            switch(accion){
                case "Listar":
                    List listaDetalleCompra = detalleCompraDAO.listar();
                    request.setAttribute("DetalleCompra", listaDetalleCompra);
                    break;

                    case "Agregar":
                        double costUnitario = Double.parseDouble(request.getParameter("txtCostoUnitario"));
                        int cant = Integer.parseInt(request.getParameter("txtCantidad"));
                        String obser = request.getParameter("txtObservaciones");
                        String tipoDPago = request.getParameter("txtTipoDePago");
                        int caroId = Integer.parseInt(request.getParameter("txtCarroId"));
                        int codCompra = Integer.parseInt(request.getParameter("txtCodigoCompra"));
                        int codProveedor = Integer.parseInt(request.getParameter("txtCodigoProveedor"));
                        detalleCompra.setCostoUnitario(costUnitario);
                        detalleCompra.setCantidad(cant);
                        detalleCompra.setObservaciones(obser);
                        detalleCompra.setTipoDePago(tipoDPago);
                        detalleCompra.setCarroId(caroId);
                        detalleCompra.setCodigoCompra(codCompra);
                        detalleCompra.setCodigoProveedor(codProveedor);
                        detalleCompraDAO.agregar(detalleCompra);
                        request.getRequestDispatcher("Controlador?menu=DetalleCompra&accion=Listar").forward(request, response);
                        break;
                        
                    case "Actualizar":
                        double costo = Double.parseDouble(request.getParameter("txtCostoUnitario"));
                        int canti = Integer.parseInt(request.getParameter("txtCantidad"));
                        String observa = request.getParameter("txtObservaciones");
                        String tipoPago = request.getParameter("txtTipoDePago");
                        detalleCompra.setCostoUnitario(costo);
                        detalleCompra.setCantidad(canti);                        
                        detalleCompra.setObservaciones(observa);                        
                        detalleCompra.setTipoDePago(tipoPago);
                        detalleCompra.setCodigoDetalleCompra(codDetalleCompra);
                        detalleCompraDAO.actulizar(detalleCompra);
                        request.getRequestDispatcher("Controlador?menu=DetalleCompra&accion=Listar").forward(request, response);//cambia de pagina (es como un cambio de escena
                     break; 
                     case "Eliminar":
                        codDetalleCompra = Integer.parseInt(request.getParameter("codigoDetalleCompra"));
                        detalleCompraDAO.eliminar(codDetalleCompra);
                        request.getRequestDispatcher("Controlador?menu=DetalleCompra&accion=Listar").forward(request, response);
                        
                    break;
                    case "Editar":
                        codDetalleCompra = Integer.parseInt(request.getParameter("codigoDetalleCompra"));
                        DetalleCompra d = detalleCompraDAO.ListarCodigoDetalleCompra(codDetalleCompra);
                        request.setAttribute("detalleCompra", d);//se envia al html el valor del codigo empleado
                        request.getRequestDispatcher("Controlador?menu=DetalleCompra&accion=Listar").forward(request, response);
                    break;       
            }
            request.getRequestDispatcher("DetalleCompra.jsp").forward(request, response);
        }else if(menu.equals("Empleado")){
            switch(accion){
                case "Listar":
                    List listaEmpleado = empleadoDAO.listar();
                    request.setAttribute("empleados", listaEmpleado);
                break;
                case "Agregar":
                    String DPI =request.getParameter("txtDPIEmpleado");
                    String nombres = request.getParameter("txtNombresEmpleado");
                    String ape = request.getParameter("txtApellidosEmpleado");
                    String fecha = request.getParameter("txtFechaEmpleado");
                    String correo =request.getParameter("txtCorreoEmpleado");
                    String telefono =request.getParameter("txtTelefonoEmpleado");
                    String user =request.getParameter("txtUsuarioEmpleado");
                    Part img = request.getPart("fileFoto");
                    InputStream inputStream = img.getInputStream();
                    String codTipo = request.getParameter("txtCodigoTipoEmpleado");
                    empleado.setDPI(DPI);
                    empleado.setNombres(nombres);
                    empleado.setApellidos(ape);
                    empleado.setFechaNacimiento(fecha);
                    empleado.setCorreo(correo);
                    empleado.setTelefono(telefono);
                    empleado.setUsuario(user);
                    empleado.setImagen(inputStream);
                    empleado.setCodigoTipoEmpleado(Integer.parseInt(codTipo));
                    empleadoDAO.agregar(empleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
                
                
                case "Editar":
                    codEmpleado = Integer.parseInt(request.getParameter("codigoEmpleado"));
                    Empleado e = empleadoDAO.listarCodigoEmpleado(codEmpleado);
                    request.setAttribute("empleado", e);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
                
                case "Actualizar":
                    String DPIEmp = request.getParameter("txtDPIEmpleado");
                    String nombresEmp = request.getParameter("txtNombresEmpleado");
                    String apeEmp = request.getParameter("txtApellidosEmpleado");
                    String fechaEmp = request.getParameter("txtFechaEmpleado");
                    String correoEmp = request.getParameter("txtCorreoEmpleado");
                    String telefonoEmp = request.getParameter("txtTelefonoEmpleado");
                    Part part = request.getPart("fileFoto");
                    InputStream imgActualizar = part.getInputStream();
                    String userEmp = request.getParameter("txtUsuarioEmpleado");
                    empleado.setDPI(DPIEmp);
                    empleado.setNombres(nombresEmp);
                    empleado.setApellidos(apeEmp);
                    empleado.setFechaNacimiento(fechaEmp);
                    empleado.setCorreo(correoEmp);
                    empleado.setTelefono(telefonoEmp);
                    empleado.setUsuario(userEmp);
                    empleado.setImagen(imgActualizar);
                    empleado.setCodigoEmpleado(codEmpleado);
                    empleadoDAO.actualizar(empleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
                
                case "Eliminar":
                    codEmpleado = Integer.parseInt(request.getParameter("codigoEmpleado"));
                    empleadoDAO.eliminar(codEmpleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
                
            }
            request.getRequestDispatcher("Empleado.jsp").forward(request, response);
        }else if(menu.equals("Cliente")){
            switch(accion){
                
                
                 case "Listar":
                    List listaCliente = clienteDao.listar();
                    request.setAttribute("clientes", listaCliente);
                    break;
                    
                    
                    
                    
                case "Agregar":
                    String nom = request.getParameter("txtNombre");
                    String ape = request.getParameter("txtApellido");
                    String dir = request.getParameter("txtDireccion");
                    String tel = request.getParameter("txtTelefono");
                    String cor = request.getParameter("txtCorreo");
                    cliente.setNombre(nom);
                    cliente.setApellido(ape);
                    cliente.setDireccion(dir);
                    cliente.setTelefono(tel);
                    cliente.setCorreo(cor);
                    clienteDao.agregar(cliente);
                    request.getRequestDispatcher("Controlador?menu=Cliente&accion=Listar").forward(request, response);
                    break;
                    
                    
                case "Editar":
                    codCliente = Integer.parseInt(request.getParameter("clienteID"));
                    Cliente e = clienteDao.listarCodigoCliente(codCliente);
                    request.setAttribute("cliente", e);
                    request.getRequestDispatcher("Controlador?menu=Cliente&accion=Listar").forward(request, response);
                    break;




                case "Actualizar":
                    String nomb = request.getParameter("txtNombre");
                    String apell = request.getParameter("txtApellido");
                    String direc = request.getParameter("txtDireccion");
                    String tele = request.getParameter("txtTelefono");
                    String corr = request.getParameter("txtCorreo");
                    cliente.setNombre(nomb);
                    cliente.setApellido(apell);
                    cliente.setDireccion(direc);
                    cliente.setTelefono(tele);
                    cliente.setCorreo(corr);
                    cliente.setClienteID(codCliente);
                    clienteDao.actualizar(cliente);
                    request.getRequestDispatcher("Controlador?menu=Cliente&accion=Listar").forward(request, response);
                    break;
               
                
                
                
                case "Eliminar":
                    codCliente = Integer.parseInt(request.getParameter("clienteID"));
                    clienteDao.eliminar(codCliente);
                    request.getRequestDispatcher("Controlador?menu=Cliente&accion=Listar").forward(request, response);
                    break;
                
                    
                    

                    
                    
            }
            request.getRequestDispatcher("Cliente.jsp").forward(request, response);
        }else if(menu.equals("Compra")){
            switch(accion){
                case "Listar":
                    List listaCompra = compraDao.listar();
                    request.setAttribute("Compra", listaCompra);
                    break;
                case "Agregar":
                    String fech = request.getParameter("txtFecha");
                    String descrip = request.getParameter("txtDescripcion");
                    double totalDoc = Double.parseDouble(request.getParameter("txtTotalDocumento"));
                    String estado = request.getParameter("txtEstado");
                    
                    Date fechaEnSQL = Date.valueOf(fech);
                    
                    compra.setFecha(fechaEnSQL);
                    compra.setDescripcion(descrip);
                    compra.setTotalDocumento(totalDoc);
                    compra.setEstado(estado);
                    compraDao.agregar(compra);
                    request.getRequestDispatcher("Controlador?menu=Compra&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    codCompra = Integer.parseInt(request.getParameter("codigoCompra"));
                    Compra c = compraDao.listarCodigoCompra(codCompra);
                    request.setAttribute("compra", c);
                    request.getRequestDispatcher("Controlador?menu=Compra&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    int codigCompra = Integer.parseInt(request.getParameter("txtCodigoCompra"));
                    String fechaCom = request.getParameter("txtFecha");
                    String descripCom = request.getParameter("txtDescripcion");
                    double totalDocCom = Double.parseDouble(request.getParameter("txtTotalDocumento"));
                    String estadoCom = request.getParameter("txtEstado");
                    
                    Date fechaComEnSQL = Date.valueOf(fechaCom);
                    
                    compra.setFecha(fechaComEnSQL);
                    compra.setDescripcion(descripCom);
                    compra.setTotalDocumento(totalDocCom);
                    compra.setEstado(estadoCom);
                    compra.setCodigoCompra(codigCompra);
                    compraDao.actualizar(compra);
                    request.getRequestDispatcher("Controlador?menu=Compra&accion=Listar").forward(request, response);
                    break;
                case "Eliminar":
                    codCompra = Integer.parseInt(request.getParameter("codigoCompra"));
                    compraDao.eliminar(codCompra);
                    request.getRequestDispatcher("Controlador?menu=Compra&accion=Listar").forward(request, response);
                    break;
            
            }
            request.getRequestDispatcher("Compra.jsp").forward(request, response);
        }else if(menu.equals("DetalleCarro")){
            switch(accion){
                case "Listar":
                    List lsitaDetalleCarro = detalleCarroDao.listar();
                    request.setAttribute("DetalleCarro", lsitaDetalleCarro);
                    break;
                case "Agregar":
                    int codDetalleCarro = Integer.parseInt(request.getParameter("txtDetalleCarro"));
                    String tipCarro = request.getParameter("txtTipoCarro");
                    int puertas = Integer.parseInt(request.getParameter("txtPuertas"));
                    String transmision = request.getParameter("txtTransmision");
                    String tipoLlantas = request.getParameter("txtTipoLlantas");
                    String color = request.getParameter("txtColor");
                    int carroId = Integer.parseInt(request.getParameter("txtCarroId"));
                    detalleCarro.setCodigoDetalleCarro(codDetalleCarro);
                    detalleCarro.setTipoCarro(tipCarro);
                    detalleCarro.setPuertas(puertas);
                    detalleCarro.setTransmision(transmision);
                    detalleCarro.setTipoLlantas(tipoLlantas);
                    detalleCarro.setColor(color);
                    detalleCarro.setCarroId(carroId);
                    detalleCarroDao.agregar(detalleCarro);
                    request.getRequestDispatcher("Controlador?menu=DetalleCarro&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    String tipoCarr = request.getParameter("txtTipoCarro");
                    int puert = Integer.parseInt(request.getParameter("txtPuertas"));
                    String transm = request.getParameter("txtTransmision");
                    String tipoDeLlantas = request.getParameter("txtTipoLlantas");
                    String col = request.getParameter("txtColor");
                    detalleCarro.setTipoCarro(tipoCarr);
                    detalleCarro.setPuertas(puert);
                    detalleCarro.setTransmision(transm);
                    detalleCarro.setTipoLlantas(tipoDeLlantas);
                    detalleCarro.setColor(col);
                    detalleCarro.setCodigoDetalleCarro(codiDetalleCarro);
                    detalleCarroDao.actulaizar(detalleCarro);
                    request.getRequestDispatcher("Controlador?menu=DetalleCarro&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    codiDetalleCarro = Integer.parseInt(request.getParameter("codigoDetalleCarro"));
                    DetalleCarro dc = detalleCarroDao.listaCodigoDetalleCarro(codiDetalleCarro);
                    request.setAttribute("detalleCarro", dc);
                    request.getRequestDispatcher("Controlador?menu=DetalleCarro&accion=Listar").forward(request, response);
                    break;
                case "Eliminar":
                    codiDetalleCarro = Integer.parseInt(request.getParameter("codigoDetalleCarro"));
                    detalleCarroDao.elminar(codiDetalleCarro);
                    request.getRequestDispatcher("Controlador?menu=DetalleCarro&accion=Listar").forward(request, response);
                    break;
            }
            
        request.getRequestDispatcher("DetalleCarro.jsp").forward(request, response);
        }else if(menu.equals("TipoEmpleado")){
            switch(accion){
                case "Listar":
                    List listaTipoEmpleado = tipoEmpleadoDao.listar();
                    request.setAttribute("TipoEmpleado", listaTipoEmpleado);
                    break;
                case"Agregar":
                    String descripcion = request.getParameter("txtDescripcion");
                    Double salario = Double.parseDouble(request.getParameter("txtSalario"));
                    Double bonificacion = Double.parseDouble(request.getParameter("txtBonificacion"));
                    String turno = request.getParameter("txtTurno");
                    tipoEmpleado.setDescripcion(descripcion);
                    tipoEmpleado.setSalarioBase(salario);
                    tipoEmpleado.setBonificacion(bonificacion);
                    tipoEmpleado.setTurno(turno);
                    tipoEmpleadoDao.agregar(tipoEmpleado);
                    request.getRequestDispatcher("Controlador?menu=TipoEmpleado&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    int codiTipoEmpleado = Integer.parseInt(request.getParameter("txtCodigoTipoEmpleado"));
                    String descrp = request.getParameter("txtDescripcion");
                    Double salar = Double.parseDouble(request.getParameter("txtSalario"));
                    Double boni = Double.parseDouble(request.getParameter("txtBonificacion"));
                    String turn = request.getParameter("txtTurno");

                    tipoEmpleado.setDescripcion(descrp);
                    tipoEmpleado.setSalarioBase(salar);
                    tipoEmpleado.setBonificacion(boni);
                    tipoEmpleado.setTurno(turn);
                    tipoEmpleado.setCodigoTipoEmpleado(codiTipoEmpleado);
                    tipoEmpleadoDao.actualizar(tipoEmpleado);
                    request.getRequestDispatcher("Controlador?menu=TipoEmpleado&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    int codTipoEmpleado = Integer.parseInt(request.getParameter("codigoTipoEmpleado"));
                    TipoEmpleado tem = tipoEmpleadoDao.listarCodigoTipoEmpleado(codTipoEmpleado);
                    request.setAttribute("tipoEmpleado", tem);
                    request.getRequestDispatcher("Controlador?menu=TipoEmpleado&accion=Listar").forward(request, response); 
                    break;
                case "Eliminar":
                    codiTipoEmpleado = Integer.parseInt(request.getParameter("codigoTipoEmpleado"));
                tipoEmpleadoDao.eliminar(codiTipoEmpleado);
                request.getRequestDispatcher("Controlador?menu=TipoEmpleado&accion=Listar").forward(request, response);
                    break;
            }
        request.getRequestDispatcher("TipoEmpleado.jsp").forward(request, response);
        }else if(menu.equals("Factura")){
            switch(accion){
                case "Listar":
                    List listaFactura = facturaDAO.listar();
                    request.setAttribute("facturas", listaFactura);
                    break;
                case "Agregar":
                    int facID = Integer.parseInt(request.getParameter("txtFacturaID"));
                    String fecEmision = request.getParameter("txtFechaEmision");
                    Double tot = Double.parseDouble(request.getParameter("txtTotal"));
                    String est = request.getParameter("txtEstado");
                    String observ = request.getParameter("txtObservaciones");
                    int cliID = Integer.parseInt(request.getParameter("txtClienteID"));
                    int codEmpleado = Integer.parseInt(request.getParameter("txtCodigoEmpleado"));
                    int carId = Integer.parseInt(request.getParameter("txtCarroId"));
                    Date fechaEmsionEnSQL = Date.valueOf(fecEmision);
                    factura.setFacturaID(facID);
                    factura.setFechaEmision(fechaEmsionEnSQL);
                    factura.setTotal(tot);
                    factura.setEstado(est);
                    factura.setObservaciones(observ);
                    factura.setClienteID(cliID);
                    factura.setCodigoEmpleado(codEmpleado);
                    factura.setCarroId(carId);
                    facturaDAO.agregar(factura);
                    request.getRequestDispatcher("Controlador?menu=Factura&accion=Listar").forward(request, response);
                    break;
                case "Actualizar":
                    String fechaEmision = request.getParameter("txtFechaEmision");
                    Double total = Double.parseDouble(request.getParameter("txtTotal"));
                    String estado = request.getParameter("txtEstado");
                    String observaciones = request.getParameter("txtObservaciones");
                    Date fechaEmisionEnSQL = Date.valueOf(fechaEmision);
                    factura.setFechaEmision(fechaEmisionEnSQL);
                    factura.setTotal(total);
                    factura.setEstado(estado);
                    factura.setObservaciones(observaciones);
                    factura.setFacturaID(factID);
                    facturaDAO.actualizar(factura);
                    request.getRequestDispatcher("Controlador?menu=Factura&accion=Listar").forward(request, response);
                    break;
                case "Editar":
                    factID = Integer.parseInt(request.getParameter("facturaID"));
                    Factura f = facturaDAO.listarFacturaID(factID);
                    request.setAttribute("factura", f);
                    request.getRequestDispatcher("Controlador?menu=Factura&accion=Listar").forward(request, response);
                    break;
                case "Eliminar":
                    factID = Integer.parseInt(request.getParameter("facturaID"));
                    facturaDAO.eliminar(factID);
                    request.getRequestDispatcher("Controlador?menu=Factura&accion=Listar").forward(request, response);
                    break;
            }
            request.getRequestDispatcher("Factura.jsp").forward(request, response);
        }else if (menu.equals("Proveedores")) {
            switch (accion) {
		case "Listar":
                    List listaProveedor = proveedoresDao.listar();
                    request.setAttribute("proveedor", listaProveedor);
                break;
                case "Agregar":
                    String nombres = request.getParameter("txtNombresProveedor");
                    String apellidos = request.getParameter("txtApellidosProveedor");
                    String direccion = request.getParameter("txtDireccionProveedor");
                    String telefono = request.getParameter("txtTelefonoProveedor");
                    String correo = request.getParameter("txtCorreoProveedor");
                    String observaciones = request.getParameter("txtObservacionesProveedor");
                    proveedores.setNombresProveedor(nombres);
                    proveedores.setApellidosProveedor(apellidos);
                    proveedores.setDireccionProveedor(direccion);
                    proveedores.setTelefonoProveedor(telefono);
                    proveedores.setCorreoProveedor(correo);
                    proveedores.setObservacionesProveedor(observaciones);
                    proveedoresDao.agregar(proveedores);
                    request.getRequestDispatcher("Controlador?menu=Proveedores&accion=Listar").forward(request, response);
                break;
                case "Actualizar":
                    nombres = request.getParameter("txtNombresProveedor");
                    apellidos = request.getParameter("txtApellidosProveedor");
                    direccion = request.getParameter("txtDireccionProveedor");
                    telefono = request.getParameter("txtTelefonoProveedor");
                    correo = request.getParameter("txtCorreoProveedor");
                    observaciones = request.getParameter("txtObservacionesProveedor");
                    proveedores.setNombresProveedor(nombres);
                    proveedores.setApellidosProveedor(apellidos);
                    proveedores.setDireccionProveedor(direccion);
                    proveedores.setTelefonoProveedor(telefono);
                    proveedores.setCorreoProveedor(correo);
                    proveedores.setObservacionesProveedor(observaciones);
                    proveedores.setCodigoProveedor(codProveedor);

                    proveedoresDao.actualizar(proveedores);
                    request.getRequestDispatcher("Controlador?menu=Proveedores&accion=Listar").forward(request, response);
                break;
                case "Editar":
                    codProveedor = Integer.parseInt(request.getParameter("codigoProveedor"));
                    Proveedores pr = proveedoresDao.listarCodigoProveedor(codProveedor);
                    request.setAttribute("proveedores", pr);
                    request.getRequestDispatcher("Controlador?menu=Proveedores&accion=Listar").forward(request, response);
                    break;
                case "Eliminar":
                    codProveedor = Integer.parseInt(request.getParameter("codigoProveedor"));
                    proveedoresDao.eliminar(codProveedor);
                    request.getRequestDispatcher("Controlador?menu=Proveedores&accion=Listar").forward(request, response);
                break;
            }
            
            request.getRequestDispatcher("Proveedores.jsp").forward(request, response);
        }else if(menu.equals("DetalleFactura")){
            switch(accion){
                case "Listar":
                    //List listarDetalleFactura = detalleFacturaDao.listarDetalleFacturas();
                    // request.setAttribute("lista", listarDetalleFactura);
                    // List listaFactura = facturaDAO.listar();
                    // request.setAttribute("lista", listaFactura);
                    
                    request.setAttribute("lista", lista);
                    request.setAttribute("totalPagar", totalPagar);
                    break;
                case "BuscarFactura":
                    int id = Integer.parseInt(request.getParameter("txtCodigoFactura"));
                    factura.setClienteID(id);
                    factura= facturaDAO.listarFacturaID(id);
                    request.setAttribute("factura", factura);
                    request.setAttribute("lista", lista);
                    request.setAttribute("totalPagar", totalPagar);

                    break;
                case "BuscarCliente":
                    int  clienteId = Integer.parseInt(request.getParameter("txtCodigoCliente"));
                    cliente.setClienteID(clienteId);
                    cliente = clienteDao.listarCodigoCliente(clienteId);
                    request.setAttribute("cliente", cliente);
                    request.setAttribute("factura", factura);
                    request.setAttribute("lista", lista);
                    request.setAttribute("totalPagar", totalPagar);

                    break;
                case "BuscarCarro":
                    int carroId = Integer.parseInt(request.getParameter("txtCodigoCarro"));
                    carro = carroDao.listarCodigoCarro(carroId);
                    request.setAttribute("carro", carro);
                    request.setAttribute("factura", factura);
                    request.setAttribute("cliente", cliente); 
                    request.setAttribute("lista", lista);
                    request.setAttribute("totalPagar", totalPagar);
                    break;

                case "Agregar":
                    request.setAttribute("cliente", cliente);
                    totalPagar = 0.0;
                    item = item + 1;
                    carroID = carro.getCarroId();
                    int IDfact = factura.getFacturaID();
                    descripcion = request.getParameter("txtDescripcion");
                    nombresCliente = request.getParameter("txtNombresCliente");
                    precio = Double.parseDouble(request.getParameter("txtPrecio"));
                    exist = Integer.parseInt(request.getParameter("txtCantidad"));
                    desc = Double.parseDouble(request.getParameter("txtDescuento"));
                    subTotal = (precio * exist) - desc;
                    DetalleFactura df = new DetalleFactura();
                    df.setFacId(IDfact);
                    df.getDetalleFacturaID();
                    df.setItem(item);
                    df.setNomCliente(nombresCliente);
                    df.setDescrip(descripcion);
                    df.setDescuento(desc);
                    df.setPrecio(precio);
                    df.setCanti(exist);
                    df.setSubTotal(subTotal);
                    lista.add(df);
                    request.setAttribute("lista", lista);
                    for (int i =0; i<lista.size(); i++) {
                        totalPagar=totalPagar+lista.get(i).getSubTotal();
                    }
                    request.setAttribute("totalPagar", totalPagar);
                    request.setAttribute("cliente", cliente);
                    break;
                case "Generar":
                    detalleFactura.setCanti(exist);
                    detalleFactura.setPrecio(precio);
                    detalleFactura.setSubTotal(subTotal);
                    detalleFactura.setDescuento(desc);
                    detalleFactura.setFacId(factID);
                    detalleFacturaDao.agregar(detalleFactura);
                    for(int i =0; i<lista.size(); i++){
                        detalleFactura=new DetalleFactura();
                        detalleFactura.setCanti(lista.get(i).getCanti());
                        detalleFactura.setPrecio(lista.get(i).getPrecioUnitario());
                        detalleFactura.setSubTotal(lista.get(i).getSubTotal());
                        detalleFactura.setDescuento(lista.get(i).getDescuento());
                        detalleFactura.setFacId(lista.get(i).getFacId());
                        detalleFacturaDao.agregar(detalleFactura);
                    }
                    
                    break;
                case "Eliminar":
                    // Obtener el itemID del parámetro
                    int itemID = Integer.parseInt(request.getParameter("item"));

                    // Buscar y eliminar el elemento en la lista usando itemID
                    for (Iterator<DetalleFactura> iterator = lista.iterator(); iterator.hasNext(); ) {
                        DetalleFactura detalleF = iterator.next();
                        if (detalleF.getItem()== itemID) {
                            iterator.remove();
                             request.setAttribute("lista", lista);
                             for (int i =0; i<lista.size(); i++) {
                                        totalPagar=totalPagar-lista.get(i).getSubTotal();
                                    }   
                                request.setAttribute("totalPagar", totalPagar);
                        }
                    }  
                    break;

            }
            request.getRequestDispatcher("DetalleFactura.jsp").forward(request, response);

    }
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(Controlador.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
