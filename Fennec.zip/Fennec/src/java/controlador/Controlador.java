/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.DetalleCompra;
import modelo.DetalleCompraDAO;
import modelo.Empleado;
import modelo.EmpleadoDAO;

/**
 *
 * @author informatica
 */
public class Controlador extends HttpServlet {
    Empleado empleado = new Empleado();
    EmpleadoDAO empleadoDAO = new EmpleadoDAO();
    int codEmpleado;
    DetalleCompra detalleCompra = new DetalleCompra();
    DetalleCompraDAO detalleCompraDAO = new DetalleCompraDAO();
    int codDetalleCompra;
    
    
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String menu = request.getParameter("menu");// Maneja el cambio e los JSP
        String accion = request.getParameter("accion");//va a manejar siempre los elementos del CRUD
        if(menu.equals("Principal2")){
            request.getRequestDispatcher("Principal2.jsp").forward(request, response);
        }else if(menu.equals("Principal")){
           
            
            
            
            
            request.getRequestDispatcher("Principal.jsp").forward(request, response);
        }else if(menu.equals("DetalleVenta")){
            switch(accion){
                case "Listar":
                    List listaDetalleCompra = detalleCompraDAO.listar();
                    request.setAttribute("DetalleCompra", listaDetalleCompra);
                    break;

                    case "Agregar":
                        double costUnitario = Double.parseDouble(request.getParameter("txtCostoUnitario"));
                        int cant = Integer.parseInt(request.getParameter("txtCantidad"));
                        String obser = request.getParameter("txtObservaciones");
                        String tipoDPago = request.getParameter("txtTipoDePago");
                        int caroId = Integer.parseInt(request.getParameter("txtCarroId"));
                        int codCompra = Integer.parseInt(request.getParameter("txtCodigoCompra"));
                        int codProveedor = Integer.parseInt(request.getParameter("txtCodigoProveedor"));
                        detalleCompra.setCostoUnitario(costUnitario);
                        detalleCompra.setCantidad(cant);
                        detalleCompra.setObservaciones(obser);
                        detalleCompra.setTipoDePago(tipoDPago);
                        detalleCompra.setCarroId(caroId);
                        detalleCompra.setCodigoCompra(codCompra);
                        detalleCompra.setCodigoProveedor(codProveedor);
                        detalleCompraDAO.agregar(detalleCompra);
                        request.getRequestDispatcher("Controlador?menu=DetalleVenta&accion=Listar").forward(request, response);
                        break;
                        
                    case "Actualizar":
                        double costo = Double.parseDouble(request.getParameter("txtCostoUnitario"));
                        int canti = Integer.parseInt(request.getParameter("txtCantidad"));
                        String observa = request.getParameter("txtObservaciones");
                        String tipoPago = request.getParameter("txtTipoDePago");
                        detalleCompra.setCostoUnitario(costo);
                        detalleCompra.setCantidad(canti);                        
                        detalleCompra.setObservaciones(observa);                        
                        detalleCompra.setTipoDePago(tipoPago);
                        detalleCompra.setCodigoDetalleCompra(codDetalleCompra);
                        detalleCompraDAO.actulizar(detalleCompra);
                        request.getRequestDispatcher("Controlador?menu=DetalleVenta&accion=Listar").forward(request, response);//cambia de pagina (es como un cambio de escena
                     break; 
                     case "Eliminar":
                        codDetalleCompra = Integer.parseInt(request.getParameter("codigoDetalleCompra"));
                        detalleCompraDAO.eliminar(codDetalleCompra);
                        request.getRequestDispatcher("Controlador?menu=DetalleVenta&accion=Listar").forward(request, response);
                        
                    break;
                    case "Editar":
                        codDetalleCompra = Integer.parseInt(request.getParameter("codigoDetalleCompra"));
                        DetalleCompra d = detalleCompraDAO.ListarCodigoDetalleCompra(codDetalleCompra);
                        request.setAttribute("detalleCompra", d);//se envia al html el valor del codigo empleado
                        request.getRequestDispatcher("Controlador?menu=DetalleVenta&accion=Listar").forward(request, response);
                    break;       
            }
            request.getRequestDispatcher("DetalleVenta.jsp").forward(request, response);
        }else if(menu.equals("Producto")){
            request.getRequestDispatcher("Producto.jsp").forward(request, response);
        }else if(menu.equals("NuevaVenta")){
            request.getRequestDispatcher("RegistrarVenta.jsp").forward(request, response);
        }else if(menu.equals("Empleado")){
            switch(accion){
                case "Listar":
                    List listaEmpleado = empleadoDAO.listar();
                    request.setAttribute("empleados", listaEmpleado);
                break;
                case "Agregar":
                    String DPI =request.getParameter("txtDPIEmpleado");
                    String nombres = request.getParameter("txtNombresEmpleado");
                    String correo =request.getParameter("txtCorreoEmpleado");
                    String telefono =request.getParameter("txtTelefonoEmpleado");
                    String user =request.getParameter("txtUsuarioEmpleado");
                    String codTipo = request.getParameter("txtCodigoTipoEmpleado");
                    empleado.setDPI(DPI);
                    empleado.setNombres(nombres);
                    empleado.setCorreo(correo);
                    empleado.setTelefono(telefono);
                    empleado.setUsuario(user);
                    empleado.setCodigoTipoEmpleado(Integer.parseInt(codTipo));
                    empleadoDAO.agregar(empleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
                
                
                case "Editar":
                    codEmpleado = Integer.parseInt(request.getParameter("codigoEmpleado"));
                    Empleado e = empleadoDAO.listarCodigoEmpleado(codEmpleado);
                    request.setAttribute("empleado", e);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
                
                case "Actualizar":
                    String DPIEmp = request.getParameter("txtDPIEmpleado");
                    String nombresEmp = request.getParameter("txtNombresEmpleado");
                    String correoEmp = request.getParameter("txtCorreoEmpleado");
                    String telefonoEmp = request.getParameter("txtTelefonoEmpleado");
                    String userEmp = request.getParameter("txtUsuarioEmpleado");
                    empleado.setDPI(DPIEmp);
                    empleado.setNombres(nombresEmp);
                    empleado.setCorreo(correoEmp);
                    empleado.setTelefono(telefonoEmp);
                    empleado.setUsuario(userEmp);
                    empleado.setCodigoEmpleado(codEmpleado);
                    empleadoDAO.actualizar(empleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
                
                case "Eliminar":
                    codEmpleado = Integer.parseInt(request.getParameter("codigoEmpleado"));
                    empleadoDAO.eliminar(codEmpleado);
                    request.getRequestDispatcher("Controlador?menu=Empleado&accion=Listar").forward(request, response);
                    break;
                
            }
            request.getRequestDispatcher("Empleado.jsp").forward(request, response);
        }
        

    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
