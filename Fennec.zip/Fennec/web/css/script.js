document.querySelector('.toggle-btn').addEventListener('click', function() {
    document.querySelector('aside').classList.toggle('expanded');
    document.querySelector('.main').classList.toggle('expanded');
});
