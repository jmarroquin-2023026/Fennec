package modelo;

import config.Conexion;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


public class FacturaDAO {
    Conexion cn = new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    int resp;
    
    
   
   //MÉTODO LISTAR
   public List listar(){
       String sql = "Select * from Factura";
       List <Factura> listaFactura = new ArrayList<>();
       try{
           con = cn.Conexion();
           ps = con.prepareStatement(sql);
           rs = ps.executeQuery();
           while(rs.next()){
               Factura fac = new Factura();
               fac.setFacturaID(rs.getInt(1));
               fac.setFechaEmision(rs.getDate(2));
               fac.setTotal(rs.getDouble(3));
               fac.setEstado(rs.getString(4));
               fac.setObservaciones(rs.getString(5));
               fac.setClienteID(rs.getInt(6));
               fac.setDPI(rs.getString(7));
               fac.setCarroID(rs.getInt(8));
               listaFactura.add(fac);
           }
       }catch(Exception e){
           e.printStackTrace();
       }
       return listaFactura;
   }

    
    //MÉTODO AGREGAR
   public int agregar (Factura fact){
       String sql = "Insert int Factura (facturaID, fechaEmisión, total, estado, observaciones, clienteID, DPI, carroID) values (?, ?, ?, ?, ?, ?, ?, ?)";
       try{
        con = cn.Conexion();
        ps = con.prepareStatement(sql);
        ps.setInt(1, fact.getFacturaID());
        ps.setDate(2, (Date) fact.getFechaEmision());
        ps.setDouble(3, fact.getTotal());
        ps.setString(4, fact.getEstado());
        ps.setString(5, fact.getObservaciones());
        ps.setInt(6, fact.getClienteID());
        ps.setString(7, fact.getDPI());
        ps.setInt(8, fact.getCarroID());
        ps.executeQuery();
       }catch(Exception e){
           e.printStackTrace();
       }
       return resp;
   }
    
    
    //MÉTODO BUSCAR
    public Factura listarFacturaID (int id){
        Factura fact = new Factura();
        String sql = "select * from Factura where facturaID="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                fact.setFacturaID(rs.getInt(1));
                fact.setFechaEmision(rs.getDate(2));
                fact.setTotal(rs.getDouble(3));
                fact.setEstado(rs.getString(4));
                fact.setObservaciones(rs.getString(5));
                fact.setClienteID(rs.getInt(6));
                fact.setDPI(rs.getString(7));
                fact.setCarroID(rs.getInt(8));
            }
        }catch(Exception e){
            e.printStackTrace();
        }
        return fact;
    }
    
    //MÉTODO EDITAR
    public int actualizar(Factura fact){
        String sql = "Update Factura set facturaID=?, fechaEmisión=?, total=?, estado=?, observaciones=?, clienteId=?, DPI=?, carroId=?";
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.setInt(1, fact.getFacturaID());
            ps.setDate(2, (Date) fact.getFechaEmision());
            ps.setDouble(3, fact.getTotal());
            ps.setString(4, fact.getEstado());
            ps.setString(5, fact.getObservaciones());
            ps.setInt(6, fact.getClienteID());
            ps.setString(7, fact.getDPI());
            ps.setInt(8, fact.getCarroID());
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
        return resp;
    }
    
    //MÉTODO ELIMINAR
    public void eliminar (int id){
        String sql = "Delete from Factura where factura ID ="+id;
        try{
            con = cn.Conexion();
            ps = con.prepareStatement(sql);
            ps.executeUpdate();
        }catch(Exception e){
            e.printStackTrace();
        }
    }
}
